package hugoauction;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HugoAuctionClient implements ClientModInitializer {

    // ACHTUNG: Nur eine Vermutung! Im Menue unter "Regex" anpassen.
    // Benoetigt die Gruppen (?<player>..) und (?<amount>..)
    private static String regexString = "(?<player>\\w{3,16}) hat dir (?<amount>[\\d.,]+)";
    private static Pattern payPattern = Pattern.compile(regexString);

    private static boolean debug = false;

    // Auktionszustand
    private static boolean running = false;
    private static String item = "";
    private static long minBid = 0;
    private static long endTime = 0;
    private static final Map<String, Long> totals = new LinkedHashMap<>();

    // Gewinner-Overlay
    private static boolean showWinner = false;
    private static String winnerName = null;
    private static long winnerAmount = 0;
    private static boolean keyHeld = false;

    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "Auktion-Menue oeffnen",
                GLFW.GLFW_KEY_K,
                KeyBinding.Category.create(Identifier.of("hugoauction", "main"))
        ));

        // Nur System-Nachrichten (GAME), nicht Spieler-Chat -> niemand kann Zahlungen faken
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) onMessage(message.getString());
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
        HudRenderCallback.EVENT.register(this::onHud);
    }

    // ---------- Chat lesen ----------

    private static void onMessage(String raw) {
        if (debug) feedback("[DEBUG] " + raw);
        if (!running) return;

        Matcher m = payPattern.matcher(raw);
        if (!m.find()) return;

        String player = m.group("player");
        long amount = parseAmount(m.group("amount"));
        if (amount <= 0) return;

        totals.merge(player, amount, Long::sum);
        feedback("Gebot: " + player + " -> insgesamt " + fmt(totals.get(player)));
    }

    private static long parseAmount(String s) {
        try {
            if (s.matches("\\d{1,3}([.,]\\d{3})+")) s = s.replaceAll("[.,]", "");
            else s = s.replace(',', '.');
            s = s.replaceAll("[^\\d.]", "");
            if (s.endsWith(".")) s = s.substring(0, s.length() - 1);
            return (long) Double.parseDouble(s);
        } catch (Exception e) {
            return 0;
        }
    }

    // ---------- Auktion steuern ----------

    static void startAuction(int seconds, long min, String itemName) {
        totals.clear();
        item = itemName;
        minBid = min;
        endTime = System.currentTimeMillis() + seconds * 1000L;
        running = true;
        showWinner = false;
    }

    static void finishAuction() {
        if (!running) return;
        running = false;
        winnerName = null;
        winnerAmount = 0;
        for (Map.Entry<String, Long> e : totals.entrySet()) {
            if (e.getValue() > winnerAmount && e.getValue() >= minBid) {
                winnerName = e.getKey();
                winnerAmount = e.getValue();
            }
        }
        showWinner = true;
        keyHeld = true; // gerade gedrueckte Taste soll den Overlay nicht sofort schliessen
    }

    static void cancelAuction() {
        running = false;
        showWinner = false;
    }

    static void announceWinner() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && winnerName != null) {
            mc.player.networkHandler.sendChatMessage(
                    "Gewinner der Auktion (" + item + "): " + winnerName + " mit " + fmt(winnerAmount) + "!");
        }
    }

    static boolean setRegex(String regex) {
        try {
            Pattern p = Pattern.compile(regex);
            p.matcher("").replaceAll("");
            payPattern = p;
            regexString = regex;
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- Tick: Taste, Timer, "beliebige Taste" ----------

    private void onTick(MinecraftClient mc) {
        while (openKey.wasPressed()) {
            if (mc.currentScreen == null && !showWinner) mc.setScreen(new AuctionScreen());
        }

        if (running && System.currentTimeMillis() >= endTime) finishAuction();

        if (showWinner && mc.getWindow() != null) {
            long win = mc.getWindow().getHandle();
            boolean any = false;
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                if (GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS) { any = true; break; }
            }
            if (any && !keyHeld && mc.currentScreen == null) showWinner = false;
            keyHeld = any;
        }
    }

    // ---------- HUD ----------

    private void onHud(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();

        if (showWinner) {
            ctx.fill(0, 0, w, h, 0xB0000000);
            drawScaled(ctx, tr, "GEWINNER", w / 2f, h * 0.22f, 5f, 0xFFFFD700);
            if (winnerName == null) {
                drawScaled(ctx, tr, "Keine Gebote", w / 2f, h * 0.45f, 3f, 0xFFFFFFFF);
            } else {
                drawScaled(ctx, tr, winnerName, w / 2f, h * 0.40f, 6f, 0xFFFFFFFF);
                drawScaled(ctx, tr, "mit " + fmt(winnerAmount), w / 2f, h * 0.60f, 3f, 0xFF55FF55);
            }
            drawScaled(ctx, tr, "Beliebige Taste zum Schliessen", w / 2f, h * 0.85f, 1f, 0xFFAAAAAA);
            return;
        }

        if (running) {
            long left = Math.max(0, (endTime - System.currentTimeMillis()) / 1000);
            String top = "-";
            long best = 0;
            for (Map.Entry<String, Long> e : totals.entrySet()) {
                if (e.getValue() > best) { best = e.getValue(); top = e.getKey(); }
            }
            ctx.drawTextWithShadow(tr, "Auktion: " + item, 6, 6, 0xFFFFD700);
            ctx.drawTextWithShadow(tr, "Hoechstgebot: " + fmt(best) + " (" + top + ")", 6, 18, 0xFFFFFFFF);
            ctx.drawTextWithShadow(tr, "Mindestgebot: " + fmt(minBid), 6, 30, 0xFFAAAAAA);
            ctx.drawTextWithShadow(tr, "Zeit: " + left + "s", 6, 42, 0xFF55FF55);
        }
    }

    private static void drawScaled(DrawContext ctx, TextRenderer tr, String text, float x, float y, float s, int color) {
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(s, s);
        ctx.drawCenteredTextWithShadow(tr, text, 0, 0, color);
        ctx.getMatrices().popMatrix();
    }

    private static String fmt(long v) {
        return String.format("%,d", v).replace(',', '.') + "$";
    }

    private static void feedback(String msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("[Auktion] " + msg), false);
    }

    // =====================================================================
    //  Menue (GUI)
    // =====================================================================

    public static class AuctionScreen extends Screen {

        // Werte merken, damit sie beim erneuten Oeffnen noch da sind
        private static String lastItem = "";
        private static String lastSeconds = "120";
        private static String lastMin = "0";

        private TextFieldWidget itemField, secField, minField, regexField;
        private String status = "";

        public AuctionScreen() {
            super(Text.literal("Auktion"));
        }

        @Override
        protected void init() {
            int fw = 200;
            int x = this.width / 2 - fw / 2;
            int y = this.height / 2 - 100;

            itemField = new TextFieldWidget(this.textRenderer, x, y, fw, 20, Text.literal("Item"));
            itemField.setMaxLength(64);
            itemField.setPlaceholder(Text.literal("Item (z.B. Diamantschwert)"));
            itemField.setText(lastItem);
            addDrawableChild(itemField);

            secField = new TextFieldWidget(this.textRenderer, x, y + 26, fw, 20, Text.literal("Sekunden"));
            secField.setMaxLength(6);
            secField.setTextPredicate(s -> s.matches("\\d*"));
            secField.setPlaceholder(Text.literal("Dauer in Sekunden"));
            secField.setText(lastSeconds);
            addDrawableChild(secField);

            minField = new TextFieldWidget(this.textRenderer, x, y + 52, fw, 20, Text.literal("Mindestgebot"));
            minField.setMaxLength(12);
            minField.setTextPredicate(s -> s.matches("\\d*"));
            minField.setPlaceholder(Text.literal("Mindestgebot"));
            minField.setText(lastMin);
            addDrawableChild(minField);

            regexField = new TextFieldWidget(this.textRenderer, x, y + 78, fw, 20, Text.literal("Regex"));
            regexField.setMaxLength(300);
            regexField.setText(regexString);
            addDrawableChild(regexField);

            addDrawableChild(ButtonWidget.builder(Text.literal("Auktion starten"), b -> onStart())
                    .dimensions(x, y + 108, fw, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("Beenden"), b -> {
                finishAuction();
                close();
            }).dimensions(x, y + 132, 98, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("Abbrechen"), b -> {
                cancelAuction();
                status = "Auktion abgebrochen.";
            }).dimensions(x + 102, y + 132, 98, 20).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("Gewinner in Chat"), b -> {
                announceWinner();
                close();
            }).dimensions(x, y + 156, 98, 20).build());

            addDrawableChild(ButtonWidget.builder(debugLabel(), b -> {
                debug = !debug;
                b.setMessage(debugLabel());
            }).dimensions(x + 102, y + 156, 98, 20).build());

            // Kein Auto-Fokus, damit der Buchstabe der Oeffnen-Taste nicht im Feld landet
        }

        private Text debugLabel() {
            return Text.literal("Debug: " + (debug ? "AN" : "AUS"));
        }

        private void onStart() {
            String itemName = itemField.getText().trim();
            if (itemName.isEmpty()) { status = "Bitte ein Item eintragen!"; return; }
            if (!setRegex(regexField.getText())) { status = "Ungueltiges Regex!"; return; }

            int seconds;
            long min;
            try {
                seconds = Integer.parseInt(secField.getText());
                min = minField.getText().isEmpty() ? 0 : Long.parseLong(minField.getText());
            } catch (NumberFormatException e) {
                status = "Dauer/Mindestgebot ungueltig!";
                return;
            }
            if (seconds < 5) { status = "Dauer mindestens 5 Sekunden!"; return; }

            startAuction(seconds, min, itemName);
            close();
        }

        @Override
        public void removed() {
            // Eingaben und Regex auch speichern, wenn nur das Menue geschlossen wird
            setRegex(regexField.getText());
            lastItem = itemField.getText();
            lastSeconds = secField.getText();
            lastMin = minField.getText();
        }

        @Override
        public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
            super.render(ctx, mouseX, mouseY, delta);
            int cx = this.width / 2;
            int y = this.height / 2 - 100;
            ctx.drawCenteredTextWithShadow(this.textRenderer, "Auktion", cx, y - 20, 0xFFFFD700);
            ctx.drawTextWithShadow(this.textRenderer, "Regex (Zahlungserkennung):", cx - 100, y + 70, 0xFFAAAAAA);
            if (!status.isEmpty()) {
                ctx.drawCenteredTextWithShadow(this.textRenderer, status, cx, y + 182, 0xFFFF5555);
            }
            if (running) {
                ctx.drawCenteredTextWithShadow(this.textRenderer, "Eine Auktion laeuft gerade", cx, y + 194, 0xFF55FF55);
            }
        }
    }
}
