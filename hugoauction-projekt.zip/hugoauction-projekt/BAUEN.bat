@echo off
call gradlew.bat build
if exist build\libs explorer build\libs
pause
